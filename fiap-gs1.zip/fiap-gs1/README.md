## Integrantes
- Lucas Santana de Paula – 95338 - https://github.com/Luquinhas11x/fiap-gs1.git
- João Pedro Bueno Milanezi – 88322
- Guilherme Tomé Dias – 94186
